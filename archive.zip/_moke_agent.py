import subprocess
import ollama 
import json  # Added missing import
from typing import Dict, List, Callable, Optional


# Sandbox for executing code safely
class Sandbox:
    def execute_code(self, code: str) -> str:
        """Execute code in a sandboxed environment."""
        try:
            # Use subprocess to run the code in a separate process
            result = subprocess.run(
                ["python3", "-c", code],
                capture_output=True,
                text=True,
                timeout=5  # Limit execution time
            )
            return result.stdout
        except subprocess.TimeoutExpired:
            return "Error: Code execution timed out."
        except Exception as e:
            return f"Error: {str(e)}"

# Custom Tool Wrapper
class Tool:
    def __init__(self, name: str, description: str, func: Callable):
        self.name = name
        self.description = description
        self.func = func

    def execute(self, input_data: str) -> str:
        return self.func(input_data)

# AI Agent
class AIAgent:
    def __init__(self, name: str, tools: Dict[str, Tool], sandbox: Sandbox):
        self.name = name
        self.tools = tools
        self.sandbox = sandbox
        self.state = {"facts": "", "goals": "", "observations": []}

    def generate_prompt(self, task: str) -> str:
        """Generate a prompt for the LLM based on the task, tools, and current state."""
        tool_descriptions = "\n".join(
            [f"- {tool.name}: {tool.description}" for tool in self.tools.values()]
        )
        prompt = f"""
        You are an AI agent named {self.name}. Your current state is:
        - Facts: {self.state['facts']}
        - Goals: {self.state['goals']}
        - Observations: {self.state['observations']}

        Available Tools:
        {tool_descriptions}

        Task: {task}

        Provide a response in the following format:
        ```
        {{
            "tool": "<tool_name>",
            "input": "<input_to_tool>"
        }}
        ```
        If no tool is applicable, generate Python code to accomplish the task.
        """
        return prompt.strip()

    def call_llm(self, prompt: str) -> str:
        """Call the LLM with a prompt and return the response."""
        try:
            response = ollama.chat(
                model="qwen2.5:0.5b",
                messages=[{"role": "user", "content": prompt}],
            )
            return response['message']['content']
        except Exception as e:
            return f"Error calling LLM: {str(e)}"

    def parse_llm_output(self, llm_output: str) -> Optional[Dict]:
        """Parse the LLM output to extract tool name and input."""
        try:
            # Look for JSON content between code blocks or just plain JSON
            if "```" in llm_output:
                # Try to extract JSON from code blocks
                code_blocks = llm_output.split("```")
                for i in range(1, len(code_blocks), 2):  # Only check content inside code blocks
                    block = code_blocks[i]
                    # Skip language identifier like "python" if present
                    if block.startswith("python") or block.startswith("json"):
                        block = block[block.find("\n"):]
                    
                    # Try to parse this block
                    try:
                        return json.loads(block.strip())
                    except:
                        continue
            
            # If no code blocks with valid JSON, try to find JSON-like content
            import re
            json_pattern = r'{\s*"tool"\s*:\s*"[^"]+"\s*,\s*"input"\s*:\s*"[^"]*"\s*}'
            matches = re.findall(json_pattern, llm_output)
            if matches:
                return json.loads(matches[0])
                
            return None
        except Exception as e:
            print(f"Failed to parse LLM output: {e}")
            return None

    def think(self, task: str) -> str:
        """Generate a plan or code using the LLM."""
        prompt = self.generate_prompt(task)
        print(f"Generated Prompt: {prompt}")
        llm_response = self.call_llm(prompt)
        print(f"LLM Response: {llm_response}")
        return llm_response

    def act(self, llm_output: str) -> str:
        """Execute the plan or code based on LLM output."""
        parsed_output = self.parse_llm_output(llm_output)
        if parsed_output and "tool" in parsed_output:
            # Use the specified tool
            tool_name = parsed_output["tool"]
            tool_input = parsed_output["input"]
            if tool_name in self.tools:
                return self.tools[tool_name].execute(tool_input)
            else:
                return f"Error: Tool '{tool_name}' not found."
        else:
            # Assume the output is code and execute it in the sandbox
            if "```python" in llm_output:
                code = llm_output.split("```python")[1].split("```")[0].strip()
                print(f"Extracted Code: {code}")
                return self.sandbox.execute_code(code)
            else:
                return "No valid action found."

    def observe(self, result: str) -> None:
        """Update the agent's state based on the result."""
        self.state["observations"].append(result)
        print(f"Observation: {result}")

    def run_cycle(self, task: str):
        """Run the Think-Act-Observe cycle."""
        print(f"Agent {self.name} is thinking...")
        llm_output = self.think(task)
        print(f"LLM Output: {llm_output}")

        print(f"Agent {self.name} is acting...")
        result = self.act(llm_output)
        print(f"Action Result: {result}")

        print(f"Agent {self.name} is observing...")
        self.observe(result)

# Runner to manage multiple agents and tools
class Runner:
    def __init__(self, agents: List[AIAgent]):
        self.agents = agents

    def run(self, task: str):
        """Run all agents in the Think-Act-Observe cycle."""
        for agent in self.agents:
            print(f"Running agent: {agent.name}")
            agent.run_cycle(task)
            print("-" * 40)

# Example Tools
def reverse_string(input_data: str) -> str:
    return input_data[::-1]

def uppercase_string(input_data: str) -> str:
    return input_data.upper()

# Main Execution
if __name__ == "__main__":
    # Initialize components
    sandbox = Sandbox()

    # Create tools
    tools = {
        "reverse": Tool("reverse", "Reverses the input string.", reverse_string),
        "uppercase": Tool("uppercase", "Converts the input string to uppercase.", uppercase_string),
    }

    # Create agents
    agent1 = AIAgent("Agent1", tools, sandbox)
    agent2 = AIAgent("Agent2", tools, sandbox)

    # Set initial state
    agent1.state["facts"] = "We need to process the string 'hello world'."
    agent1.state["goals"] = "Reverse string as needed."
    agent2.state["facts"] = "We need to analyze the string 'hello world'."
    agent2.state["goals"] = "Upercase all letters."

    # Create runner
    runner = Runner([agent1, agent2])

    # Run the agents with a task
    task = "Process the string 'hello world'."
    runner.run(task)