import subprocess
import ollama
import json
import re
from typing import Dict, List, Callable, Optional, Any
from dataclasses import dataclass, field


# Sandbox for executing code safely
class Sandbox:
    def execute_code(self, code: str) -> str:
        """Execute code in a sandboxed environment."""
        try:
            # Use subprocess to run the code in a separate process
            result = subprocess.run(
                ["python3", "-c", code],
                capture_output=True,
                text=True,
                timeout=5  # Limit execution time
            )
            return result.stdout
        except subprocess.TimeoutExpired:
            return "Error: Code execution timed out."
        except Exception as e:
            return f"Error: {str(e)}"
    
    def execute_tool(self, tool_name: str, input_data: Any) -> Dict[str, Any]:
        """Execute a tool with the given input."""
        try:
            if tool_name in self.tools:
                output = self.tools[tool_name].execute(input_data)
                return {"success": True, "output": output}
            else:
                return {"success": False, "error": f"Tool {tool_name} not found"}
        except Exception as e:
            return {"success": False, "error": str(e)}


# Custom Tool Wrapper
class Tool:
    def __init__(self, name: str, description: str, func: Callable):
        self.name = name
        self.description = description
        self.func = func

    def execute(self, input_data: Any) -> Any:
        return self.func(input_data)


@dataclass
class AgentMemory:
    """
    Manages agent's memory and learning.
    """
    observations: List[Dict[str, Any]] = field(default_factory=list)
    past_plans: List[Dict[str, Any]] = field(default_factory=list)
    
    def record_observation(self, observation: Dict[str, Any]):
        """
        Record an observation from an action.
        
        Args:
            observation (Dict[str, Any]): Observation details
        """
        self.observations.append(observation)
    
    def record_plan(self, plan: List[Dict[str, Any]]):
        """
        Record a plan for future reference.
        
        Args:
            plan (List[Dict[str, Any]]): Plan steps
        """
        self.past_plans.append({
            "timestamp": len(self.past_plans),
            "plan": plan
        })


class LLMReasoner:
    """
    Provides reasoning capabilities using a Language Model.
    """
    def __init__(self, llm_model="qwen2.5:0.5b"):
        """
        Initialize the reasoner with a language model.
        """
        self.model = llm_model
    
    def generate(self, prompt: str) -> str:
        """Call the LLM with a prompt and return the response."""
        try:
            response = ollama.chat(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
            )
            return response['message']['content']
        except Exception as e:
            return f"Error calling LLM: {str(e)}"
    
    def generate_plan(self, goal: str, context: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Generate a step-by-step plan to achieve the goal.
        
        Args:
            goal (str): The objective to be achieved
            context (Dict[str, Any]): Current context and available information
        
        Returns:
            List of plan steps with details
        """
        prompt = f"""
        Goal: {goal}
        Context: {json.dumps(context)}
        
        Generate a detailed, actionable plan to achieve this goal. 
        Each plan step should include:
        - A tool to use (if applicable)
        - Input for the tool
        - Expected outcome
        
        Available tools: {", ".join(context.get("tools", {}).keys())}
        
        Provide the plan as a JSON list of steps, where each step has:
        {{
            "tool": "<tool_name>",
            "input": "<input_to_tool>",
            "expected_outcome": "<what you expect to happen>"
        }}
        """
        
        try:
            response = self.generate(prompt)
            # Try to extract JSON from the response
            json_pattern = r'\[.*\]'
            matches = re.findall(json_pattern, response, re.DOTALL)
            if matches:
                return json.loads(matches[0])
            return []
        except Exception as e:
            print(f"Error generating plan: {e}")
            return []


class GoalOrientedAgent:
    """
    An agent that can reason, plan, act, and learn towards achieving a goal.
    """
    def __init__(self, name: str, tools: Dict[str, Tool], description: str = ""):
        """
        Initialize the agent with reasoning and execution capabilities.
        
        Args:
            name (str): Name of the agent
            tools (Dict[str, Tool]): Available tools for action
            description (str): Description of the agent's role
        """
        self.reasoner = LLMReasoner()
        self.sandbox = Sandbox()
        self.sandbox.tools = tools  # Make tools available to sandbox
        self.memory = AgentMemory()
        self.name = name
        self.description = description
        self.tools = tools
        self.state = {"facts": "", "goals": "", "observations": []}
    
    def solve_goal(self, goal: str, context: Dict[str, Any] = None, max_iterations: int = 3):
        """
        Attempt to solve a goal through iterative planning and execution.
        
        Args:
            goal (str): The objective to achieve
            context (Dict[str, Any]): Starting context and information
            max_iterations (int): Maximum number of planning iterations
        
        Returns:
            Final result of goal-solving attempt
        """
        if context is None:
            context = {}
        
        # Add tools to context
        context["tools"] = {name: tool.description for name, tool in self.tools.items()}
        context["facts"] = self.state["facts"]
        context["current_observations"] = self.state["observations"]
        
        print(f"Agent {self.name} is solving goal: {goal}")
        
        for iteration in range(max_iterations):
            print(f"Iteration {iteration+1}/{max_iterations}")
            
            # Generate plan
            print("Generating plan...")
            plan = self.reasoner.generate_plan(goal, context)
            self.memory.record_plan(plan)
            print(f"Plan: {json.dumps(plan, indent=2)}")
            
            # Execute plan steps
            for i, step in enumerate(plan):
                print(f"Executing step {i+1}/{len(plan)}: {step}")
                
                tool_name = step.get('tool')
                input_data = step.get('input', {})
                
                # Execute tool in sandbox
                result = self.sandbox.execute_tool(tool_name, input_data)
                
                # Record observation
                observation = {
                    "step": step,
                    "result": result
                }
                self.memory.record_observation(observation)
                self.state["observations"].append(observation)
                
                print(f"Result: {result}")
                
                # Update context with result
                if result.get('success'):
                    context[f"result_{i}"] = result['output']
                
                # Optional: Check goal achievement
                if self._check_goal_achieved(goal, context):
                    print(f"Goal achieved after {i+1} steps!")
                    return context
            
            # If goal not achieved, use memory to refine approach
            context = self._refine_context(context)
        
        print("Maximum iterations reached without achieving goal.")
        return context
    
    def _check_goal_achieved(self, goal: str, context: Dict[str, Any]) -> bool:
        """
        Check if the goal has been achieved based on current context.
        
        Args:
            goal (str): Goal to evaluate
            context (Dict[str, Any]): Current context
        
        Returns:
            Boolean indicating goal achievement
        """
        # Ask the LLM if the goal has been achieved
        prompt = f"""
        Goal: {goal}
        Current Context: {json.dumps(context)}
        
        Has the goal been achieved based on the current context?
        Answer with just "Yes" or "No".
        """
        
        response = self.reasoner.generate(prompt).strip().lower()
        return response.startswith("yes")
    
    def _refine_context(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Refine context based on past observations and failures.
        
        Args:
            context (Dict[str, Any]): Current context
        
        Returns:
            Refined context
        """
        # Add observations to context
        observations_summary = []
        for obs in self.memory.observations[-5:]:  # Get the last 5 observations
            observations_summary.append({
                "step": obs.get("step", {}),
                "success": obs.get("result", {}).get("success", False),
                "output": obs.get("result", {}).get("output", "")
            })
        
        context["recent_observations"] = observations_summary
        return context
    
    def set_state(self, facts: str, goals: str):
        """Set the agent's state."""
        self.state["facts"] = facts
        self.state["goals"] = goals
    
    def run_cycle(self, task: str):
        """Run goal-solving cycle for a given task."""
        print(f"Agent {self.name} is starting task: {task}")
        self.solve_goal(task)


# Example Tools
def reverse_string(input_data: str) -> str:
    return input_data[::-1]

def uppercase_string(input_data: str) -> str:
    return input_data.upper()

def analyze_text(input_data: str) -> Dict[str, Any]:
    """Analyze a text string and return statistics."""
    return {
        "length": len(input_data),
        "word_count": len(input_data.split()),
        "char_counts": {char: input_data.count(char) for char in set(input_data)},
        "has_numbers": any(c.isdigit() for c in input_data)
    }

# Runner to manage multiple agents and tools
class Runner:
    def __init__(self, agents: List[GoalOrientedAgent]):
        self.agents = agents

    def run(self, task: str):
        """Run all agents to solve the given task."""
        for agent in self.agents:
            print(f"Running agent: {agent.name}")
            agent.run_cycle(task)
            print("-" * 40)


# Main Execution
if __name__ == "__main__":
    # Create tools
    tools = {
        "reverse": Tool("reverse", "Reverses the input string.", reverse_string),
        "uppercase": Tool("uppercase", "Converts the input string to uppercase.", uppercase_string),
        "analyze": Tool("analyze", "Analyzes text and returns statistics.", analyze_text),
    }

    # Create agents
    agent1 = GoalOrientedAgent("Transformer", tools, "Transforms and processes text")
    agent2 = GoalOrientedAgent("Analyzer", tools, "Analyzes and extracts insights from text")

    # Set initial state
    agent1.set_state(
        facts="We need to process the string 'hello world'.",
        goals="Transform the string as needed."
    )
    agent2.set_state(
        facts="We need to analyze the string 'hello world'.",
        goals="Extract insights from the string."
    )

    # Create runner
    runner = Runner([agent1, agent2])

    # Run the agents with a task
    task = "Process the string 'hello world' and provide useful transformations and insights."
    runner.run(task)